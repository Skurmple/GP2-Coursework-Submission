//Needed includes
#include "Game.h"
#include "Camera.h"
#include <iostream>
#include <string>
//

Transform transform; //Stores the transform class

Game::Game() //Constructor
{
	_gameState = GameState::PLAY;
	MonitorScreen* _gameDisplay = new MonitorScreen(); //new display
    Mesh* mesh1();
	Mesh* mesh2();
	Mesh* mesh3();
}

Game::~Game() //Destructor
{
}

void Game::run() //Initial function run by main.cpp
{
	initSystems(); 
	gameLoop();
}

void Game::initSystems() //Initialises most needed variables
{
	_gameDisplay.initialiseScreen();
	
	sound.addAudioTrack("..\\res\\background.wav");
	sound.addSoundEffect("..\\res\\bang.wav");

	mesh1.loadModel("..\\res\\cube.obj");
	mesh2.loadModel("..\\res\\sphere.obj");
	mesh3.loadModel("..\\res\\monkey3.obj");
	
	myCamera.initCamera(glm::vec3(0, 0, -5), 70.0f, (float)_gameDisplay.getWidth()/_gameDisplay.getHeight(), 0.01f, 1000.0f);

	shader.init("..\\res\\shader"); //new shader

	counter = 1.0f;
}

void Game::gameLoop() //Core game loop
{
	while (_gameState != GameState::EXIT)//Runs the game while the game state is not set to exit
	{
		playSound(0, mesh1.getSpherePos()); //Plays the background music
		processInput(); //Processes input
		drawGame(); //Draws game to screen
		collision(mesh1.getSpherePos(), mesh1.getSphereRadius(), mesh2.getSpherePos(), mesh2.getSphereRadius()); //Handles collision
	}
}

void Game::processInput() //Processes input
{
	SDL_Event evnt; //Creates an evnt variable that handles any event, aka user input

	while(SDL_PollEvent(&evnt)) //get and process events
	{
		switch (evnt.type)
		{
			case SDL_QUIT: //Checks for the SDL_QUIT event
				_gameState = GameState::EXIT; //Exits the game
				break;
		}
	}
	
}


bool Game::collision(glm::vec3 m1Pos, float m1Rad, glm::vec3 m2Pos, float m2Rad) //Collision handling
{
	float distance = ((m2Pos.x - m1Pos.x)*(m2Pos.x - m1Pos.x) + (m2Pos.y - m1Pos.y)*(m2Pos.y - m1Pos.y) + (m2Pos.z - m1Pos.z)*(m2Pos.z - m1Pos.z)); //Variable for distance between meshes
	
	if (distance*distance < (m1Rad + m2Rad)) //Checks if the meshes are overlapping
	{
		cout << distance << '\n'; //Outputs that distance to the console
		sound.playSoundEffect(0); //Plays a sound effect
		return true;
	}
	else
	{
		return false;
	}
}

void Game::drawGame() //Draws game to screen
{
	_gameDisplay.wipeScreen(0.0f, 0.0f, 0.0f, 1.0f); //Clears previous graphics on screen
	
	Texture texture("..\\res\\bricks.jpg"); //load texture
	Texture texture1("..\\res\\water.jpg"); //load texture
	Texture texture2("..\\res\\redbrick.jpg"); //load texture

	//Creates the first mesh
	transform.SetPos(glm::vec3(sinf(counter), 0.5, 0.0));
	transform.SetRot(glm::vec3(0.0, 0.0, counter * 5));
	transform.SetScale(glm::vec3(0.6, 0.6, 0.6));
	shader.Bind();
	shader.Update(transform, myCamera);
	texture2.Bind(0);
	mesh1.draw();
	mesh1.updateSphereData(*transform.GetPos(), 0.6f);
	//

	//Creates the second mesh
	transform.SetPos(glm::vec3(-sinf(counter), -0.5, -sinf(counter)*5));
	transform.SetRot(glm::vec3(0.0, 0.0, counter * 5));
	transform.SetScale(glm::vec3(0.6, 0.6, 0.6));
	shader.Bind();
	shader.Update(transform, myCamera);
	texture1.Bind(0);
	mesh2.draw();
	mesh2.updateSphereData(*transform.GetPos(), 0.6f);
	counter = counter + 0.05f;
	//

	//Creates the third mesh
	transform.SetPos(glm::vec3(0, -3, 5));
	transform.SetRot(glm::vec3(0.0, 0.0, counter * 5));
	transform.SetScale(glm::vec3(0.6, 0.6, 0.6));
	shader.Bind();
	shader.Update(transform, myCamera);
	texture.Bind(0);
	mesh3.draw();
	mesh3.updateSphereData(*transform.GetPos(), 0.6f);
	//
				
	glEnableClientState(GL_COLOR_ARRAY); 
	glEnd();

	_gameDisplay.changeBuffers(); //Swaps buffers
} 

void Game::playSound(unsigned int Source, glm::vec3 pos) //Plays sound
{
	sound.playAudioTrack(); //Plays the background music
}