#pragma once

//Needed includes
#include <glm\glm.hpp>
#include <GL\glew.h>
#include <string>
#include "obj_loader.h"
//

struct Vertex //Declaration of vertex structure
{
public:
	Vertex(const glm::vec3& pos, const glm::vec2& texCoord) //Constructor
	{
		this->pos = pos;
		this->texCoord = texCoord;
		this->normal = normal;
	}

	//Declaration of getters
	glm::vec3* GetPos() { return &pos; }
	glm::vec2* GetTexCoord() { return &texCoord; }
	glm::vec3* GetNormal() { return &normal; }
	//

private:
	//Variable declaration
	glm::vec3 pos;
	glm::vec2 texCoord;
	glm::vec3 normal;
	//
};

struct Sphere //Declaration of sphere structure (for collision)
{
public:

	Sphere(){} //Constructor

	//Declaration of getters
	glm::vec3 GetPos() { return pos; }
	float GetRadius() { return radius; }
	//

	//Declaration of setters
	void SetPos(glm::vec3 pos)
	{
		this->pos = pos;
	}
	void SetRadius(float radius)
	{
		this->radius = radius;
	}
	//

private:

	//Variable declaration
	glm::vec3 pos;
	float radius;
	//
};

class Mesh //Declaration of mesh class
{
public:
	Mesh(); //Constructor
	~Mesh(); //Destructor


	void draw(); //Draws the mesh
	void init(Vertex* vertices, unsigned int numVertices, unsigned int* indices, unsigned int numIndices); //Initialises the model's variables
	void loadModel(const std::string& filename); //Gets the model from a file
	void initModel(const IndexedModel& model); //Initialises the model with Glew
	void updateSphereData(glm::vec3 pos, float radius); //Updates collision as the mesh moves

	//Declaration of getters
	glm::vec3 getSpherePos() { return meshSphere.GetPos(); }
	float getSphereRadius() { return meshSphere.GetRadius(); }
	//

private:


	//Enumerator of virtual buffers
	enum
	{
		POSITION_VERTEXBUFFER,
		TEXCOORD_VB,
		NORMAL_VB,
		INDEX_VB,
		NUM_BUFFERS
	};
	//

	//Variable Declaration
	Sphere meshSphere;
	GLuint vertexArrayObject;
	GLuint vertexArrayBuffers[NUM_BUFFERS];
	unsigned int drawCount;
	//
};