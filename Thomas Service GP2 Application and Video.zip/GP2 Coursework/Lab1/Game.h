#pragma once

//Needed includes
#include <SDL\SDL.h>
#include <GL/glew.h>
#include <SDL/SDL_mixer.h>
#include "MonitorScreen.h" 
#include "Shader.h"
#include "Mesh.h"
#include "Texture.h"
#include "Sounds.h"
#include "transform.h"
//

enum class GameState{PLAY, EXIT}; //Enumerator of game states

class Game //Declaration of Game class
{
public:
	Game(); //Constructor
	~Game(); //Destructor
	
	void run(); //Function that starts the game, called in main.cpp

private:

	void initSystems(); //Initialises most variables
	void processInput(); //Function to process input
	void gameLoop(); //Core gameplay loop
	void drawGame(); //Renders game to screen
	bool collision(glm::vec3 m1Pos, float m1Rad, glm::vec3 m2Pos, float m2Rad); //Function that checks for collision
	void playSound(unsigned int Source, glm::vec3 pos); //Function to play sound at a set location

	//Variable declaration
	MonitorScreen _gameDisplay;
	GameState _gameState;
	Mesh mesh1;
	Mesh mesh2;
	Mesh mesh3;
	Camera myCamera;
	Shader shader;
	Sounds sound;
	float counter;
	unsigned int whistle;
	//
};

