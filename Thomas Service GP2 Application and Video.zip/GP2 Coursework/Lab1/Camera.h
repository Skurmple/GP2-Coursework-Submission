#pragma once

//Needed includes
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
//

struct Camera //Declaration of a Camera structure
{
public:
	Camera() //Constructor
	{
	}
	
	void initCamera(const glm::vec3& pos, float fov, float aspect, float nearClip, float farClip) //Camera initialisation function
	{
		this->pos = pos;
		this->forward = glm::vec3(0.0f, 0.0f, 1.0f);
		this->up = glm::vec3(0.0f, 1.0f, 0.0f);
		this->projection = glm::perspective(fov, aspect, nearClip, farClip);
	}

 	glm::vec3 getPos() //Getter for the camera's position
	{
		return this->pos;
	}

	inline glm::mat4 GetViewProjection() const //Getter for the camera's projection matrix
	{
		return projection * glm::lookAt(pos, pos + forward, up);
	}

protected:
private:
	//Variable declaration
	glm::mat4 projection;
	glm::vec3 pos;
	glm::vec3 forward;
	glm::vec3 up;
	//
};


