//Needed includes
#include "Sounds.h"
//

Sounds::Sounds() //Constructor
{
    //Variable initialisation
    int audio_rate = 22050;
    Uint16 audio_format = AUDIO_S16SYS;
    int audio_channels = 2;
    int audio_buffers = 4096;
    //

    Mix_OpenAudio(audio_rate, audio_format, audio_channels, audio_buffers); //Initialises audio with SDL Mixer

    if (Mix_OpenAudio(audio_rate, audio_format, audio_channels, audio_buffers) != 0) //Checks if audio initialised correctly
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Couldn't init audio: %s", Mix_GetError()); //Outputs an error if audio did not initialise correctly
        exit(-1);
    }
}

Sounds::~Sounds() //Destructor
{
    SDL_Quit(); //Quits the game
}

void Sounds::addSoundEffect(const char* path)  //Adds sound effects to the game
{
    Mix_Chunk* tmpChunk = Mix_LoadWAV(path); //Stores the .wav

    if (tmpChunk != nullptr) //If .wav is found and stored correctly
    {
        mSoundEffectBank.push_back(tmpChunk);
        std::cout << (mSoundEffectBank.size() - 1) << " Sound is Ready, path: " << path << '\n'; //Outputs a message to show the .wav has been found
    }
    else //Otherwise if .wav could not be found
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Couldn't init audio: %s", Mix_GetError()); //Outputs a message to show the .wav was not found
    }
}

void Sounds::playSoundEffect(const int which) const //Plays a sound effect
{
    if (which > mSoundEffectBank.size() - 1) //Checks if sound chosen does not exist in stored sound files
    {
        std::cout << "Sound out of range.\n"; //Outputs a message to show that sound file does not exist
        return;
    }

    Mix_PlayChannel(-1, mSoundEffectBank[which], 0); //Plays sound

    std::cout << "Played Sound: " << which << '\n'; //Outputs a message showing sound was played
}

void Sounds::addAudioTrack(const char* path) //Adds an audio track to the game
{
    gMusic = Mix_LoadMUS(path); //Loads audio file from file path

    if (gMusic == NULL) //Checks if audio file was found
    {
        printf("Failed to load beat music! SDL_mixer Error: %s\n", Mix_GetError()); //Outputs a message showing file could not be found
    }
}

void Sounds::playAudioTrack() //Plays audio track
{
    if (Mix_PlayingMusic() == 0) //Checks if game is not already playing music
    {
        //Play the music
        Mix_PlayMusic(gMusic, -1);
    }
}