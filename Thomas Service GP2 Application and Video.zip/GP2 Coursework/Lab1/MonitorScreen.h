#pragma once

//Needed includes
#include <SDL/SDL.h>
#include <GL\glew.h>
#include <iostream>
#include <string>
using namespace std;
//


class MonitorScreen //Declaration of the screen's class
{
public:
	MonitorScreen(); //Constructor
	~MonitorScreen(); //Destructor
	void initialiseScreen(); //Initialises the screen
	void changeBuffers(); //Buffer swapping to allow seamless graphics
	void wipeScreen(float r, float g, float b, float a); //Clears everything currently on the screen

	//Declaration of getters
	float getWidth();
	float getHeight();
	//

private:

	void returnError(std::string errorString); //Quits game in case errors flag up
	
	//Variable declaration
	SDL_GLContext glContext;
	SDL_Window* sdlWindow;
	float windowWidth;
	float windowHeight;
	//
};

