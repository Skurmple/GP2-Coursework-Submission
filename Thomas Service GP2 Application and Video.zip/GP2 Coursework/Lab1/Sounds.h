#pragma once

//Needed includes
#include <SDL/SDL_mixer.h>
#include <SDL/SDL.h>
#include <iostream>
#include <vector>
//

class Sounds //Declaration of sound class
{
public:
	Sounds(); //Cosntructor
	~Sounds(); //Destructor

	void addSoundEffect(const char* path); //Finds an audio file from a file path
	void addAudioTrack(const char* path); //Finds an audio file from a file path
	void playSoundEffect(const int which) const; //Plays one of the sound effects stored
	void playAudioTrack(); //Plays a stored audio track

private:

	//Variable declaration
	Mix_Music* gMusic;
	std::vector<Mix_Chunk*> mSoundEffectBank;
	//
};
