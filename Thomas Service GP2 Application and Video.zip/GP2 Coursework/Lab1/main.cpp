//Needed includes
#include <iostream>
#include "Game.h"
//

int main(int argc, char** argv) //argument used to call SDL main
{
	Game mainGame; //Main game class
	mainGame.run(); //Initial function to start the game

	return 0; //Ends the game when reached
}